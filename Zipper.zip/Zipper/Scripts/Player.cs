﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public delegate void GiveItems(int oxygen = 0, int crew = 0, int maxCrew = 0);
    public static GiveItems giveItems;

    public float knockbackForce;
    public int knockbackPenalty;
    private Rigidbody2D rb2d;

    public int oxygen;
    public int crew;
    public int maxCrew;

    public Text o2Text;
    public Text o2ConsumptionText;
    public GameObject o2QuickDisplay;
    public Text o2QuickDisplayText;
    public GameObject allCrew;

    private AudioSource audioSource;
    public AudioClip crewEject;

    public float quickDisplayLength;
    private bool flickering;

    IEnumerator QuickDisplay()
    {
        o2QuickDisplay.SetActive(true);
        yield return new WaitForSeconds(quickDisplayLength);
        o2QuickDisplay.SetActive(false);
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Bullet")
        {
            Bullet bullet = coll.GetComponent<Bullet>();

            if (bullet.isFriendly == false)
            {
                Destroy(coll.gameObject);

                oxygen -= bullet.oxygenHit;
                StartCoroutine(QuickDisplay());
                if (!flickering)
                {
                    StartCoroutine(Flicker());
                }
            }
        }
        if (coll.gameObject.tag == "Enemy")
        {
            Knockback(knockbackPenalty);
        }
        if(coll.gameObject.tag == "Knockback")
        {
            Knockback(0);
        }
    }

    // Use this for initialization
    void Start ()
    {
        giveItems += GetItems;
        LevelManager.onNextStage += PumpOxygenIn;
        LevelManager.onStageComplete += CheckGameOver;

        rb2d = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();

        UpdateCrewUI();
    }

    void OnDestroy()
    {
        giveItems -= GetItems;
        LevelManager.onNextStage -= PumpOxygenIn;
        LevelManager.onStageComplete -= CheckGameOver;
    }

    // Update is called once per frame
    void Update ()
    {
        o2Text.text = ":" + oxygen;
        o2ConsumptionText.text = "/" + crew * 25;
        o2QuickDisplayText.text = oxygen.ToString();

        if(LevelManager.state == LevelManager.State.Playing)
        {
            CheckGameOver();
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            ReleaseCrew();
        }
	}

    void ReleaseCrew()
    {
        if(crew > 1)
        {
            crew -= 1;
            audioSource.PlayOneShot(crewEject);
            UpdateCrewUI();
        }
        else
        {
            //Do Later
        }
    }

    //Method for "GiveItem" delegate which allows other classes to interact with this once
    void GetItems(int newOxygen = 0, int newCrew = 0, int increaseMaxCrew = 0)
    {
        oxygen += newOxygen;
        if(crew + newCrew <= maxCrew) { crew += newCrew; }
        else { print("Outta space for more crew members buddy!"); }
        maxCrew += increaseMaxCrew;
    }

    void PumpOxygenIn()
    {
        oxygen -= crew * 25;
    }

    IEnumerator Flicker()
    {
        flickering = true;
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        Color defaultColour = sprite.color;
        sprite.color = Color.red;
        yield return new WaitForSeconds(0.2f);
        sprite.color = defaultColour;
        flickering = false;
    }

    void Knockback(int penalty)
    {
        rb2d.AddForce(new Vector2(0, -knockbackForce * Time.deltaTime), ForceMode2D.Impulse);
        StartCoroutine(QuickDisplay());
        oxygen -= penalty;
    }

    void UpdateCrewUI()
    {
        for(int k = 0; k < crew; k++)
        {
            allCrew.transform.GetChild(k).gameObject.SetActive(true);
        }
        for(int k = crew; k < maxCrew; k++)
        {
            allCrew.transform.GetChild(k).gameObject.SetActive(false);
        }
    }

    void CheckGameOver()
    {
        if(oxygen < 0)
        {
            LevelManager.onGameOver();
        }
    }
}
