﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jukebox : MonoBehaviour
{
    public delegate void PlayGlobal(AudioClip clip, float volume = 1);
    public static PlayGlobal playGlobal;
    public static PlayGlobal pauseAndPlay;

    public AudioSource musicSource;
    public AudioSource otherAudioSource;

	// Use this for initialization
	void Start ()
    {
        musicSource = GetComponent<AudioSource>();
        playGlobal += Play;
        pauseAndPlay += PauseAndPlay;
	}

    void OnDestroy()
    {
        playGlobal -= Play;
        pauseAndPlay -= PauseAndPlay;
    }

    // Update is called once per frame
    void Update ()
    {
        if (!otherAudioSource.isPlaying && !musicSource.isPlaying)
        {
            musicSource.UnPause();
        }
	}

    //Only call this method if the object will be destroyed during playing
    void Play(AudioClip clip, float volume = 1)
    {
        musicSource.PlayOneShot(clip, volume);
    }

    void PauseAndPlay(AudioClip clip, float volume = 1)
    {
        musicSource.Pause();
        otherAudioSource.clip = clip;
        otherAudioSource.Play();
    }
}
