﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Screenshake : MonoBehaviour
{
    public delegate void StartShake();
    public static StartShake startShake;

    private bool returning;
    private bool shake;
    public float intensity;
    public float speed;

    private Vector3 defaultPos;
    private Vector3 newPos;

    public new Camera camera;

	// Use this for initialization
	void Start()
    {
        startShake += Begin;

        returning = false;
        defaultPos = camera.transform.position;
        newPos = new Vector3(defaultPos.x + intensity, defaultPos.y - intensity, defaultPos.z);
    }

    void OnDestroy()
    {
        startShake -= Begin;
    }

    // Update is called once per frame
    void Update ()
    {
        if (!shake)
        {
            return;
        }
        if(returning == false)
        {
            camera.transform.position = Vector3.Lerp(transform.position, newPos, speed);
        }
        else
        {
            camera.transform.position = Vector3.Lerp(transform.position, defaultPos, speed);
        }

        if(transform.position == newPos)
        {
            returning = true;
        }

        if(returning == true && transform.position == defaultPos)
        {
            Restart();
        }
    }

    void Restart()
    {
        shake = false;
        returning = false;
        
        newPos = new Vector3(defaultPos.x + intensity, defaultPos.y - intensity, defaultPos.z);
    }

    void Begin()
    {
        shake = true;
        returning = false;

        newPos = new Vector3(defaultPos.x + intensity, defaultPos.y - intensity, defaultPos.z);
    }
}
