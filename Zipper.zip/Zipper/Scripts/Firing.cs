﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Firing : MonoBehaviour
{
    public enum Type { player, enemy, friendly }
    public Type type;

    public Player player;

    private bool firing;
    [Header("The Lower, the faster")]
    public float defaultFireSpeed;
    private float actualFireSpeed;

    public GameObject firePoint;
    public GameObject bullet;

    private GameObject bulletHolder;

    private AudioSource audioSource;
    public AudioClip fireSound;

    private ParticleSystem particleSystem;

    private IEnumerator WaitTime()
    {
        firing = true;
        yield return new WaitForSeconds(Random.Range(0.1f, 2f));
        firing = false;
    }

    //Co-routine which fires and then has a cooldown period
    private IEnumerator WaitFire(bool friendly)
    {
        switch (type)
        {
            case Type.player:
                {
                    if (Input.GetMouseButton(0)) { Fire(friendly); }
                }
                break;
            case Type.enemy:
                {
                    Fire(friendly);
                }
                break;
            case Type.friendly:
                {
                    Fire(friendly);
                }
                break;
        }
        
        firing = true;

        //Wait until script can fire again
        yield return new WaitForSeconds(actualFireSpeed);
        firing = false;
    }

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        particleSystem = GetComponent<ParticleSystem>();

        if(type != Type.player)
        {
            //To add some variation in firing
            StartCoroutine(WaitTime());
        }

        bulletHolder = GameObject.FindGameObjectWithTag("Bullet Holder");

        actualFireSpeed = defaultFireSpeed;
    }

    // Update is called once per frame
    void Update ()
    {
        switch (type)
        {
            case Type.player:
                {
                    //The more crew the player has the faster the gun can fire
                    actualFireSpeed = defaultFireSpeed / (player.crew / 2f);

                    if (Input.GetMouseButton(0))
                    {
                        //If not on cooldown
                        if (firing == false)
                        {
                            //Fire
                            StartCoroutine(WaitFire(true));
                        }
                    }
                }
                break;
            case Type.enemy:
                {
                    if (firing == false)
                    {
                        //Fire
                        StartCoroutine(WaitFire(false));
                    }
                }
                break;
            case Type.friendly:
                {
                    if (firing == false && LevelManager.state == LevelManager.State.Playing)
                    {
                        //Fire
                        StartCoroutine(WaitFire(true));
                    }
                }
                break;
        }
	}

    void Fire(bool friendly)
    {
        //Spawn projectile and initialize
        GameObject entity = Instantiate(bullet, firePoint.transform.position, transform.rotation, bulletHolder.transform);
        entity.GetComponent<Bullet>().Initialize(friendly);

        if(type == Type.player)
        {
            audioSource.PlayOneShot(fireSound, 1f);
        }
        else
        {
            audioSource.PlayOneShot(fireSound, 0.5f);
        }
        particleSystem.Play();

        if (type == Type.player)
        {
            Screenshake.startShake();
        }
    }
}
