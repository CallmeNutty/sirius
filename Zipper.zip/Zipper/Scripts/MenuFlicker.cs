﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuFlicker : MonoBehaviour
{
    //The Gameobject which holds all menu's
    public GameObject menuRoot;

    public void NextScreen(GameObject menu)
    {
        for (int k = 0; k < menuRoot.transform.childCount; k++)
        {
            menuRoot.transform.GetChild(k).gameObject.SetActive(false);
        }
        menu.SetActive(true);
    }

    public void ChangeScene(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex, LoadSceneMode.Single);
    }
}
