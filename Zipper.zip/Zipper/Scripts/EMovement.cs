﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EMovement : MonoBehaviour
{
    public enum MovementType { LeftRight, Track, Rush }
    public MovementType movementType;

    public enum State { Free, Frozen, Positioning}
    public State state;

    private GameObject rootPositions;

    public bool isFriendly;
    public float speed;

    private float defaultYPoint;
    //When positioning when the round is over
    private float randomPosChosen;
    private Vector2 viewportPoint;
    private Vector2 targetLocation;

    private GameObject trackedObject;

	// Use this for initialization
	void Start ()
    {
        PickRandomPos();

        if(!isFriendly && movementType == MovementType.Rush)
        {
            trackedObject = GameObject.FindGameObjectWithTag("Player");
        }

        if (isFriendly)
        {
            LevelManager.onStageComplete += EndOfRound;
            LevelManager.onNextStage += Reposition;
        }

        rootPositions = GameObject.FindGameObjectWithTag("Root Positions");
        //Update position of entity relative to camera
        viewportPoint = Camera.main.WorldToViewportPoint(transform.position);
        defaultYPoint = gameObject.transform.position.y;

        if (isFriendly == false && viewportPoint.y > 1)
        {
            state = State.Positioning;
            targetLocation = GetSpot().position;
        }
        else
        {
            SetUpMovement();
        }
    }

    void OnDestroy()
    {
        if (isFriendly)
        {
            LevelManager.onStageComplete -= EndOfRound;
            LevelManager.onNextStage -= Reposition;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            //When allies are clipping
            PickRandomPos();
        }

        //If an enemy is just spawned and is above the cam
        if (isFriendly == false && viewportPoint.y > 1)
        {
            transform.position = Vector2.MoveTowards(transform.position, targetLocation, speed * 3 * Time.deltaTime);

            if(transform.position.x == targetLocation.x && transform.position.y == targetLocation.y)
            {
                state = State.Free;
                SetUpMovement();
            }
        }

        //If friendly is repositioning back to their default spot
        if(isFriendly == true && state == State.Positioning)
        {
            transform.position = Vector2.MoveTowards(transform.position, ReturnDefaultPos(), speed * Time.deltaTime);

            if(transform.position.y == ReturnDefaultPos().y)
            {
                state = State.Free;
            }
        }

        if (state == State.Free && LevelManager.state == LevelManager.State.Playing)
        {
            switch (movementType)
            {
                case MovementType.LeftRight:
                    {
                        //Update position of bullet relative to camera
                        viewportPoint = Camera.main.WorldToViewportPoint(transform.position);

                        //If to the the very left of the camera
                        if (viewportPoint.x <= 0.05f)
                        {
                            //Set the new location to the very right of the camera
                            targetLocation = Camera.main.ViewportToWorldPoint(new Vector3(1, 0));
                            targetLocation.y = transform.position.y;
                        }
                        //If to the the very right of the camera
                        else if (viewportPoint.x >= 0.95f)
                        {
                            //Set the new location to the very left of the camera
                            targetLocation = Camera.main.ViewportToWorldPoint(new Vector3(0, 0));
                            targetLocation.y = transform.position.y;
                        }

                        transform.position = Vector2.MoveTowards(transform.position, targetLocation, speed * Time.deltaTime);

                        break;
                    }
                case MovementType.Track:
                    {
                        //If you are a friendly and are not tracking an object
                        if (trackedObject == null && isFriendly)
                        {
                            trackedObject = GameObject.FindGameObjectWithTag("Enemy");
                        }
                        //Or if you are not a friendly and not tracking an object
                        else if (trackedObject == null && isFriendly == false)
                        {
                            trackedObject = GameObject.FindGameObjectWithTag("Player");
                        }

                        if (trackedObject != null)
                        {
                            //Set the target location to the x co-ordinate of the tracked object
                            targetLocation = new Vector2(trackedObject.transform.position.x, transform.position.y);

                            transform.position = Vector2.MoveTowards(transform.position, targetLocation, speed * Time.deltaTime);
                        }

                        break;
                    }
                case MovementType.Rush:
                    {
                        transform.position = Vector2.MoveTowards(transform.position, trackedObject.transform.position, speed * Time.deltaTime);

                        break;
                    }
            }
        }
    }

    Transform GetSpot()
    {
        //Finds a spot from the spotlist and returns it
        return rootPositions.transform.GetChild(Random.Range(0, rootPositions.transform.childCount));
    }

    void SetUpMovement()
    {
        switch (movementType)
        {
            case MovementType.LeftRight:
                {
                    //Randomise the initial direction, "0" is left, "1" is right
                    int leftRight = Random.Range(0, 2);

                    if (leftRight == 0)
                    {
                        targetLocation = Camera.main.ViewportToWorldPoint(new Vector3(0, 0));
                        targetLocation.y = transform.position.y;
                        print("Left");
                    }
                    else
                    {
                        targetLocation = Camera.main.ViewportToWorldPoint(new Vector3(1, 0));
                        targetLocation.y = transform.position.y;
                        print("Right");
                    }
                    break;
                }
            default:
                break;
        }
    }

    void EndOfRound()
    {
        transform.position = Vector2.MoveTowards(transform.position, Camera.main.ViewportToWorldPoint(new Vector2(randomPosChosen, 0.5f)), speed * Time.deltaTime);
    }

    void PickRandomPos()
    {
        randomPosChosen = Random.Range(0.1f, 0.9f);
    }

    void Reposition()
    {
        state = State.Positioning;
    }

    Vector2 ReturnDefaultPos()
    {
        Vector2 position;
        position.x = Camera.main.ViewportToWorldPoint(new Vector2(viewportPoint.x, 0)).x;
        position.y = defaultYPoint;

        return position;
    }
}
