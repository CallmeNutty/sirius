﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public int hits;
    public int oxygenHit;
    public bool isFriendly;
    [Tooltip("Destroy bullet after ricocheting with the walls twice")]
    public bool destroyOnSecondRicochet;
    private int ricochets;

    public Rigidbody2D rb2d;
    private Vector2 viewportPoint;

    public AudioSource audioSource;
    public AudioClip interactClip;

    IEnumerator Clear()
    {
        yield return new WaitForSeconds(4f);
        Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        if(coll.gameObject.tag == "Border")
        {
            if (destroyOnSecondRicochet)
            {
                ricochets++;
                //Bounce
                transform.Rotate(new Vector3(0, 0, transform.rotation.z > 0 ? 90 : -90));
                audioSource.PlayOneShot(interactClip, 0.8f);
            }
            if (ricochets == 2) { Destroy(gameObject); }
        }
    }

    void Start()
    {
        StartCoroutine(Clear());
    }

    void Update()
    {
        //Update position of bullet relative to camera
        viewportPoint = Camera.main.WorldToViewportPoint(transform.position);

        //If outside of main camera view
        if (viewportPoint.x > 1 || viewportPoint.x < 0 || viewportPoint.y > 1 || viewportPoint.y < 0)
        {
            Destroy(gameObject);
        }
    }

    //Call this when the object is fired
    public void Initialize(bool friendly)
    {
        isFriendly = friendly;
    }
}
