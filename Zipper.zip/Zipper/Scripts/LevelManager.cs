﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class Level
{
    public int levelNumber;
    public string flavourText;
    public int maxEnemies;

    public List<GameObject> allEnemies = new List<GameObject>();
}

public class LevelManager : MonoBehaviour
{
    public List<Level> allLevels = new List<Level>();
    private Level currentLevel;

    public enum State { Playing, Waiting }
    public static State state;

    public delegate void OnStage();
    public static OnStage onStageComplete;
    public static OnStage onNextStage;
    public static OnStage onGameOver;

    public Text waitingText;
    public Text roundText;
    public GameObject gameOverScreen;

    [Header("The Gameobject which contains every enemy")]
    public GameObject rootEnemy;

    public bool playedVictory;
    public AudioClip roundComplete;

	// Use this for initialization
	void Start ()
    {
        onGameOver += GameOver;
        currentLevel = allLevels[0];
        Time.timeScale = 1;
    }

    void OnDestroy()
    {
        onGameOver -= GameOver;
    }

    // Update is called once per frame
    void Update ()
    {
        //If there is an enemy slot to be filled
        if (rootEnemy.transform.childCount < currentLevel.maxEnemies && currentLevel.allEnemies.Count > 0 && state == State.Playing)
        {
            Instantiate(currentLevel.allEnemies[0], Camera.main.ViewportToWorldPoint(new Vector3(0.5f,1.2f)), currentLevel.allEnemies[0].transform.rotation, rootEnemy.transform);
            currentLevel.allEnemies.RemoveAt(0);
        }

        //If all enemies for this level are gone
        if(currentLevel.allEnemies.Count == 0 && rootEnemy.transform.childCount == 0)
        {
            int currentLevelNumber = currentLevel.levelNumber;
            allLevels.Remove(currentLevel);

            //If every level has been played
            if (allLevels.Count == 0)
            {
                onStageComplete();
                //Game won
                state = State.Waiting;

                waitingText.enabled = true;
                roundText.enabled = false;
                waitingText.text = "Round... hang on. You made it! Woah!" +
                    "\nYou Finished my game. Thanks! :D" +
                    "\nI hope you enjoyed playing it just as much as I did making it." +
                    "\nHave a good day sir!" +
                    "\n You can press 'Esc' to go back to the home screen and 'Esc' again to close the game";
            }
            else
            {
                if(onStageComplete != null) { onStageComplete(); }

                roundText.enabled = false;
                waitingText.enabled = true;
                waitingText.text = "Round: " + currentLevelNumber + " completed! " +
                    "\nFrom here you can eject crew members ('C') so you consume less oxygen or" +
                    "\ndestroy some of your fellow crafts for instant oxygen." +
                    "\nOtherwise, press 'P' to continue to the next round." +
                    "\nHave a safe ride home commander!";
                state = State.Waiting;
            }
            if (!playedVictory) { Jukebox.pauseAndPlay(roundComplete); playedVictory = true; }
        }

        if(state == State.Waiting && Input.GetKeyDown(KeyCode.P))
        {
            Advance();
        }
	}

    void GameOver()
    {
        gameOverScreen.SetActive(true);
        Time.timeScale = 0;
    }

    void Advance()
    {
        onNextStage();
        currentLevel = allLevels[0];

        state = State.Playing;
        roundText.enabled = true;
        roundText.text = "ROUND: " + currentLevel.levelNumber + " " + currentLevel.flavourText;
        waitingText.enabled = false;

        playedVictory = false;
    }
}
