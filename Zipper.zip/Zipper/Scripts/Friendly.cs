﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Friendly : MonoBehaviour
{
    public int oxygen;

    [Header("Prevent accidental killing")]
    public int hitsToKill;
    private int maxHitsToKill;

    [Header("The Gameobject which displays how much oxygen is gained upon destruction (UI)")]
    public GameObject oxygenAmount;

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Bullet")
        {
            Bullet bullet = coll.GetComponent<Bullet>();

            if (bullet.isFriendly == true && LevelManager.state == LevelManager.State.Waiting)
            {
                Destroy(coll.gameObject);
                hitsToKill -= 1;

                if(hitsToKill == 0)
                {
                    Player.giveItems(oxygen);
                    Destroy(gameObject);
                }
            }
            else if(bullet.isFriendly == false)
            {
                Destroy(coll.gameObject);
            }
        }
    }

    // Use this for initialization
    void Start ()
    {
        LevelManager.onNextStage += ResetHealth;
        LevelManager.onNextStage += HideOxygen;
        LevelManager.onStageComplete += DisplayOxygen;

        maxHitsToKill = hitsToKill;
	}

    void OnDestroy()
    {
        LevelManager.onNextStage -= ResetHealth;
        LevelManager.onNextStage -= HideOxygen;
        LevelManager.onStageComplete -= DisplayOxygen;
    }

    // Update is called once per frame
    void Update ()
    {
		
	}

    void ResetHealth()
    {
        hitsToKill = maxHitsToKill;
    }

    void DisplayOxygen()
    {
        oxygenAmount.GetComponent<Text>().text = oxygen.ToString();
        oxygenAmount.SetActive(true);
    }

    void HideOxygen()
    {
        oxygenAmount.SetActive(false);
    }
}
