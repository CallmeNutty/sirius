﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public enum Type { None, Exploderiser }
    public Type specialType;

    private bool flickering;
    private int hitsLeft;
    public int maxHits;

    public GameObject bulletsInside;

    private AudioSource audioSource;
    public AudioClip deathSound;
    public AudioClip hitSound;

    void OnTriggerEnter2D(Collider2D coll)
    {
        if(coll.gameObject.tag == "Bullet")
        {
            Bullet bullet = coll.GetComponent<Bullet>();

            if (bullet.isFriendly)
            {
                switch (specialType)
                {
                    case Type.Exploderiser:
                        {
                            Destroy(coll.gameObject);

                            hitsLeft -= bullet.hits;
                            if(hitsLeft <= 0)
                            {
                                bulletsInside.SetActive(true);
                            }

                            break;
                        }
                    default:
                        {
                            Destroy(coll.gameObject);

                            hitsLeft -= bullet.hits;
                            if (hitsLeft <= 0)
                            {
                                Jukebox.playGlobal(deathSound);
                                Destroy(gameObject);
                            }
                            else
                            {
                                audioSource.PlayOneShot(hitSound);
                                if (!flickering)
                                {
                                    StartCoroutine(Flicker());
                                }
                            }

                            break;
                        }
                }
            }
        }
    }

    // Use this for initialization
    void Start ()
    {
        hitsLeft = maxHits;

        audioSource = GetComponent<AudioSource>();
	}

    IEnumerator Flicker()
    {
        flickering = true;
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        Color defaultColour = sprite.color;
        sprite.color = Color.red;
        yield return new WaitForSeconds(0.2f);
        sprite.color = defaultColour;
        flickering = false;
    }
}
